<?php 

class Item {

	private $model;
	private $type;

	public function __construct($type,$model){
		$this->model = $model;
		$this->type = $type;
	}
}

class AbstractMobilePhone extends Item {

	public $type = "MobilePhone";

	public function __construct($model){
		parent::__construct($type,$model);
	}
}

class AbstractTablet extends Item {

	public $type = "Tablet";

	public function __construct($model){
		parent::__construct($type,$model);
	}
}

class AbstractLaptopComputer extends Item {

	public $type = "LaptopComputer";

	public function __construct($model){
		parent::__construct($type,$model);
	}
}

class LaptopComputer extends AbstractLaptopComputer {
	
	public $model;

	public function __construct($model){
		$this->model = $model;
		parent::__construct($model);
	}
}

class Tablet extends AbstractTablet {
	
	public $model;

	public function __construct($model){
		$this->model = $model;
		parent::__construct($model);
	}
}

class MobilePhone extends AbstractMobilePhone {
	
	public $model;

	public function __construct($model){
		$this->model = $model;
		parent::__construct($model);
	}
}

 ?>