<?php require_once('../inc/Connection.php');  
  $db = Database::getInstance();
    $connection = $db->getConnection(); ?>

<?php 

abstract class AbstractObserver {
    abstract function update(AbstractSubject $subject_in);
}

abstract class AbstractSubject {
    abstract function attach(AbstractObserver $observer_in);
    abstract function detach(AbstractObserver $observer_in);
    abstract function notify();
}

class Observer extends AbstractObserver {
	private $name = "";
    public function __construct($new_name) {
    	$this->name = $new_name;
    }
    public function update(AbstractSubject $subject) {
      echo "";  
    }
}

class Subject extends AbstractSubject {
    private $favoritePatterns = NULL;
    private $observers = array();
    function __construct() {
    }
    function attach(AbstractObserver $observer_in) {
      $this->observers[] = $observer_in;
    }
    function detach(AbstractObserver $observer_in) {
      foreach($this->observers as $okey => $oval) {
        if ($oval == $observer_in) { 
          unset($this->observers[$okey]);
        }
      }
    }
    function notify() {      
      $sql = "SELECT * FROM store";
      $result = mysqli_query($connection, $sql);
      $resultCheck = mysqli_num_rows($result);
      if($resultCheck>0){
        while ($row = mysqli_fetch_assoc($result)) {
          
        }
      }
    }
    function updateFavorites($newFavorites) {
      $this->favorites = $newFavorites;
      $this->notify();
    }
    function getFavorites() {
      return $this->favorites;
    }
    function getArray(){
      return $this;
    }
}

 ?>