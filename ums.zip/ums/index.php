<?php require_once('../inc/Connection.php');
	$db = Database::getInstance();
    $connection = $db->getConnection();  ?> 

<?php 

require_once('load.php');

//$connection = new mysqli('localhost','root','','mychoice_db');
$item = new MyChoice();
$obs = 1;
$sql = "SELECT * FROM store WHERE Observer!='$obs' ";
$result = mysqli_query($connection, $sql);

if($result){
	while ($row = mysqli_fetch_assoc($result)) {
		$item->attach(new Seller($row['Store_id']));
		$query="UPDATE store SET Observer='$obs' ";	
		$result1=mysqli_query($connection,$query);
	}
}
//$item->attach($user->sign());
//$item->attach(new Seller(2));
//$item->attach(new Seller(3)); 
//$item->attach(new Seller(4));
//$item->attach(new Seller(5));
//$item->attach(new Seller(6));
$item->notify("Mobile Phone","Huawei Nova 2i");
$item->notify("Laptop Computer","HP Pavilion");
$item->notify("Tablet","Samsung Galaxy");
$item->notify("Mobile Phone","Samsung Galaxy S10+");

 ?>

<?php mysqli_close($connection); ?>