<?php require_once('../inc/Connection.php') ;
$db = Database::getInstance();
$connection = $db->getConnection(); ?>

<?php 
	 
	$folder = "";

	function display($row,$folder){
		echo "<div class='item-column'>";
			echo "<div class='logo clearfix' id='img_dir'>";
				echo "<img src='../images/$folder/".$row['Logo']."'>";
			echo "</div>";
			echo "<h3>" . $row['Item_name'] . "</h3>";
		echo "</div>";
	}

	function displayClient($row,$folder){
		echo "<div class='item-column'>";
			echo "<div class='logo clearfix' id='img_dir'>";
				echo "<img src='../images/$folder/".$row['Logo']."'>";
			echo "</div>";
			echo "<h3>" . $row['Store_name'] . "<br>Telephone : " . $row['Telephone'] . "<br>Mobile : " . $row['Mobile'] . "</h3>";
		echo "</div>";
	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>MyChoice.lk</title>
	<link rel="stylesheet" type="text/css" href="../css/customer.css">
</head>
<body>
	<div class="wrapper">
		<div class="top-bar clearfix">
			<ul>
				<li>Do you like to join with us..?<a href="">Click Here</a></li>
			</ul>
		</div>
		<header class="clearfix">
			<div class="title">
				<h1>MyChoice.lk</h1>
			</div>
			<div class="main">
				<ul>
					<li><a href="services.php">Services</a></li>
					<li><a href="clients.php">Our Clients</a></li>
					<li><a href="contact_us.php">Contact us</a></li>
				</ul>
			</div>
			<div class="about">
				<h2><br>"We just compare,<br>Choice is yours."</h2>
				<p>Finding a new device ?<br><br>Hiring new sellers in the industry ?<br><br>Getting ahead in the field of new technological devices ?<br><br>It all starts right here! This is your gateway to the world of modern technological appliances; the best collection on the internet...!<br><br></p>
			</div>
		</header>
		<div class="search-bar">
			<div class="search">
				<form action="../search_trial/Search.php" method="get">
					<input type="text" name="q" dir="itr" placeholder="     Search">
					<input type="submit" value="     ">
				</form>
			</div>
			<div class="search-how">
				<select>
	  				<option value="SearchBySeller">Search By Seller</option>
	  				<option value="SearchByItem" selected>Search By Item</option>
				</select>
			</div>
		</div>
		<div class="display-items">
			<div class="item">
				<?php
				$query="SELECT * FROM item WHERE Category_id=1 ";
				$folder = "Mobile_Phones";
				$result=mysqli_query($connection,$query);
				$no_of_rows = mysqli_num_rows($result);
				if($no_of_rows>0){
					echo "<h2>Mobile Phones</h2>";
					while($row=mysqli_fetch_array($result)){
						display($row,$folder);
					}
				} ?>
			</div>
			<div class="item clearfix">
				<?php 
				$query="SELECT * FROM item WHERE Category_id=2 ";
				$folder = "Laptops";
				$result=mysqli_query($connection,$query);
				$no_of_rows = mysqli_num_rows($result);
				if($no_of_rows>0){
					echo "<h2>Laptop Computers</h2>";
					while($row=mysqli_fetch_array($result)){
						display($row,$folder);
					}
				} ?>
			</div>
			<div class="item clearfix">
				<?php 
				$query="SELECT * FROM item WHERE Category_id=3 ";
				$folder = "Tablets";
				$result=mysqli_query($connection,$query);
				$no_of_rows = mysqli_num_rows($result);
				if($no_of_rows>0){
					echo "<h2>Tablets</h2>";
					while($row=mysqli_fetch_array($result)){
						display($row,$folder);
					}
				} ?>
			</div>
			<div class="item">
				<?php 
				$query="SELECT * FROM store";
				$folder = "Sellers";
				$result=mysqli_query($connection,$query);
				$no_of_rows = mysqli_num_rows($result);
				if(mysqli_num_rows($result)>0){
					echo "<h2>Our Clients</h2>";
					while($row=mysqli_fetch_array($result)){
						displayClient($row,$folder);
					}
				} ?>
			</div>	
		</div>
		<div class="final">
			<h2>final line</h2>
		</div>
	</div>
</body>
</html>