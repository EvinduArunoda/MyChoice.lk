<?php 

require_once('../inc/Connection.php');

$db = Database::getInstance();
$connection = $db->getConnection();
$Store_id=$_SESSION['Store_id'];
$msg = "";

 ?>

 <?php 

 	$folder = "";

	function display($row,$price,$folder){
		echo "<div class='item-column'>";
			echo "<div class='pict' id='img_dir'>";
				echo "<img src='../images/$folder/".$row['Logo']."'>";
			echo "</div>";
			echo "<h3>" . $row['Item_name'] . "<br>$price</h3>";
		echo "</div>";
	}

  ?>
 
<!DOCTYPE html>
<html>
<head>
	<title>NOVUS CREATIONS</title>
	<link rel="stylesheet" type="text/css" href="../css/seller_acc.css">
</head>
<body>
	<div class="wrapper">
		<header>
			<div class="main"> 
				<ul>
					<li class="active"><a href="#">Home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="clients.php">Our Clients</a></li>
					<li><a href="contact_us.php">Contact us</a></li>
					<li><a href="about_us.php">About us</a></li>		
				</ul>
			</div>
			<div class="title">
				<h1>MyChoice.lk</h1>
			</div>
		</header>
		<div class="side-bar clearfix">
			<div class="category clearfix">
				<h4>Account</h4>
				<ul>
					<li><a href="../php/seller_acc.php">My Profile</a></li>
				</ul>
			</div>
			<div class="category clearfix">
				<h4>My Products</h4>
				<ul>
					<li><a href="#">Smart Phones</a></li>
					<li><a href="#">Laptop Computers</a></li>
					<li><a href="#">Tablerts</a></li>
				</ul>
			</div>
			<div class="category clearfix">
				<h4>Settings</h4>
				<ul>		
					<li><a href="../php/add_logo.php">Edit Profile</a></li>
					<li><a href="../php/add_item.php">Add Item</a></li>
					<li><a href="../php/remove_item.php">Remove Item</a></li>
					<li><a href="../php/logout.php">Log Out</a></li>
					<li><a href="#">Delete Account</a></li>
				</ul>
			</div>
		</div>
		<div class="data">
			<div class="print">
				<?php 
					interface Observer{
						public function update($type,$model);
					}

					class Seller implements Observer {

						public $id;

						public function __construct($id){
							$this->id = $id;
						}

						public function update($type,$model){
							echo "New " . "$type" . " is added to the website just now. You can add " . "$model" . " to your store. Thank you!<br>";
						}
					}
				 ?>
			</div>	
			<?php 
			$query="SELECT * FROM store WHERE Store_id='$Store_id' ";
			$result=mysqli_query($connection,$query);
			while($row=mysqli_fetch_assoc($result)){
				echo "<div class='profile'>";
					echo "<h3>" . $row['Store_name'] . "<br>" . $row['Company_name'] . "</h3>";
				echo "</div>";
				echo "<div class='pic' id='img_dir'>";
					echo "<img src='../images/Sellers/".$row['Logo']."'>";
				echo "</div>";
			} ?>
		</div>
		<div class="items">
			<h2>Mobile Phones</h2>
			<?php 
			$folder = "Mobile_Phones";
			$query1="SELECT * FROM availabilitycheck WHERE Store_id='$Store_id' ";
			$result1=mysqli_query($connection,$query1);
			$count = mysqli_num_rows($result1);
			while($row1=mysqli_fetch_assoc($result1)){
				if($row1['Delete_request']==0){
					$item_id = $row1['Item_id'];
					$query2="SELECT * FROM item WHERE Item_id='$item_id' ";
					$result2=mysqli_query($connection,$query2);
					if ($result2){
						$numOfRows=mysqli_num_rows($result2);
						if($numOfRows>0) {
			      			$row2= mysqli_fetch_assoc($result2);
			      			display($row2,$row1['Price'],$folder);
						}
					}
				}
			} ?>
		</div>
	</div>
</body>
</html>