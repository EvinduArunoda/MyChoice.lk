<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<meta charset="utf-8">
	<title>login</title>
	<link rel="stylesheet" href="css/logindup.css">
</head>
<body>
	<header>
		<div class="main">
			<form class="box" action="login.php" method="post">
				<h1>LOG IN</h1>
				<input type="text" name="username" placeholder="username" required="" id=""><br>
				<input type="password" name="password" placeholder="Password" required="" id=""><br>
				<input type="submit" name="submit"value="Log in" ><br>
			</form>
		</div>
	</header>
</body>
</html>