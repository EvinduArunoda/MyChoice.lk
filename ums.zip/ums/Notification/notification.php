<?php 

function fetchAll($query){
	$connection=mysqli_connect('localhost','root','','mychoice_db');
	$stmt = $connection->query($query);
	return $stmt->fetchAll();
}

function performQuery($query){
	$connection=mysqli_connect('localhost','root','','mychoice_db');
	$stmt = $connection->prepare($query);
	if($stmt->execute()){
		return true;
	}else{
		return false;
	}
}

 ?>