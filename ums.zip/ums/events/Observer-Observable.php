<?php

interface Observable{
	public function attach(Observer $observer);
	public function detach(Observer $observer);
	public function notify($type,$model);
}

class MyChoice implements Observable {

	protected $storage;
	public $type;
	public $model;

	public function __construct(){
		$this->storage = new \SplObjectStorage();
	}
	public function attach(Observer $observer){
		$this->storage->attach($observer);
	}
	public function detach(Observer $observer){
		if(!$this->storage->contains($observer)){
			return;
		} 
		$this->storage->detach($observer);
	}
	public function notify($type,$model){
		$this->type = $type;
		$this->model = $model;
		if(!count($this->storage)){
			return;
		}
		foreach ($this->storage as $observer) {
			$observer->update($type,$model);
		}
	}
}

 ?>