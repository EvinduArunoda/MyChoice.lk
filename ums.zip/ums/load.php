<?php 

include('inc/Connection.php');
include('events/Observer-Observable.php');
include('php/seller_acc.php');

 ?>