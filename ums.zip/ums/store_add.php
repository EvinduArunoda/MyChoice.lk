<?php require_once('inc/Connection.php') ;?>
<?php 
	if (isset($_POST['submit'])){
		$companyName=$_POST['companyName'];
		$storeName=$_POST['storeName'];
		$email=$_POST['email'];
		$regCode=$_POST['regCode'];
		$phone=$_POST['phone'];
		$mobile=$_POST['mobile'];
		$fax=$_POST['fax'];
		$website=$_POST['website'];
		$address=$_POST['address'];
		$province=$_POST['province'];
		$city=$_POST['city'];
		$postalCode=$_POST['postalCode'];
		$description=$_POST['description'];
		$is_deleted=0;
		$query="INSERT INTO storedata(companyName,storeName,email,regCode,phone,mobile,fax,website,address,province,city,postalCode,description)VALUES ('{$companyName}','{$storeName}','{$email}','{$regCode}','{$phone}','{$mobile}','{$fax}','{$website}','{$address}','{$province}','{$city}','{$postalCode}','{$description}')";	
		$result=mysqli_query($connection,$query);
		if($result){
				echo "Data of The Store is added Successfully";
				header('Location: seller_home.php');
		}
	}
	elseif (isset($_POST['cancel'])) {
		header('Location: seller_home.php');
	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Add a New Store</title>
	<link rel="stylesheet" type="text/css" href="css\store_add.css">
</head>
<body>
	<div class="wrapper">
		<header>
			<div class="title">
			<h1>Add a New Store</h1>
		</div>
		<div class="data">
			<form class="basic-data" action="store_add.php" method="post" enctype="multipart/form-data">
				<h1>Basic Information</h1>
				<input type="text" placeholder="Company Name" name="companyName"><br>
				<input type="text" placeholder="Store Name" name="storeName"><br>
				<input type="text" placeholder="Email Address" name="email"><br>
				<input type="text" placeholder="Registration Code" name="regCode"><br>
				<br><input type="file" name="logo" id="logo">
				<div class="upload">
					<input type="submit" value="Upload Logo" name="uploadImage">
				</div>
			</form>
			<form class="contact-data">
				<h1>Contact Information</h1>
				<input type="text" placeholder="Phone Number" name="phone"><br>
				<input type="text" placeholder="Mobile" name="mobile"><br>
				<input type="text" placeholder="Fax" name="fax"><br>
				<input type="text" placeholder="Website" name="website"><br>
				<input type="text" placeholder="Postal Address" name="address">
			</form>
			<form class="other-data">
				<h1>Other Information</h1>
				<input type="text" placeholder="Province" name="province"><br>
				<input type="text" placeholder="City" name="city"><br>
				<input type="text" placeholder="Postal Code" name="postalCode"><br>
				<textarea name="description" placeholder="Enter the Description..." form="usrform"></textarea>
				<input type="submit" value="Submit" name="submit">
				<div class="cancel">
					<input type="submit" value="Cancel" name="cancel">
				</div>
			</form>
		</div> <!--data-->
		</header>
	</div> <!--wrapper-->
</body>
</html>

<?php mysqli_close($connection); ?>