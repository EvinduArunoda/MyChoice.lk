<?php require_once('inc/Connection.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>NOVUS CREATIONS</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<header>
		<div class="title">
			<h1>MyChoice.lk</h1>
		</div>
		<div class="button">
			<a class="btn" href="http://localhost/ums/signup.php">SIGN UP</a>
			<a class="btn" href="http://localhost/ums/login.php">LOG IN</a>
		</div>
	</header>
</body>
</html>
<?php mysqli_close($connection); ?>